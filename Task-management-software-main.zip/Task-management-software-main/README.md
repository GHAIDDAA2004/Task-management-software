# Task-management-software
Task management software
TaskMate is an application through which we can manage personal tasks. It improves users' productivity by organizing daily tasks and ensuring their successful completion.
  Users can rely on this application to improve their time management and increase their effectiveness in completing daily tasks.
  
Requirements
- Run the application on the Android operating system.
- Having a mobile device.
- Android Studio and Java language must be used to develop the application.
- Use of espresso-core and recyclerview offices.
- 
Jobs
- Create tasks.
- Amendment to previous bulimia.
- Delete completed tasks.
- 
Installation instructions

1. Download the application.
2. Install the application on your device.
3. Add your tasks and organize them according to your preferences.

User's Manual

Home screen :
When you launch the app, a temporary display will appear and then the main screen showing the different task lists available.

Add a new task :
To add a new task, click on the “Add Task” button and enter the necessary details.

Defining tasks :
To select a task, choose the task you want to select by clicking on it.

Delete tasks :
Select the task you wish to delete and then click the Delete button. The deletion will be confirmed before the operation is performed.

Modifying tasks :
Select the task you wish to modify and then click the Edit button.

TaskMate helps users achieve personal organization and increase productivity, and allows them to identify and edit important tasks
And follow up on progress and achievements, as it enhances the effectiveness of time management and achieving goals with high accuracy.

Contributors

Ruba Ahmed Mohammed 

Aisha Amer Muhammad Al-Hamidi Asiri

Jawaher mohammed

Huda Ibrahim mdawe

Ghaida Hassan Alhady

Sadeem Al-Hassan

 contact us

444809353@kku.edu.sa
